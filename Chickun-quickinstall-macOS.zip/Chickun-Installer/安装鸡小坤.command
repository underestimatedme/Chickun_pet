#!/bin/zsh
# Local, offline installer. CHICKUN_INSTALL_ROOT is an optional isolated test destination.
set -euo pipefail

bundle_dir="${0:A:h}"
source_dir="$bundle_dir/chickun"
install_root="${CHICKUN_INSTALL_ROOT:-${CODEX_HOME:-$HOME/.codex}}"
pets_dir="$install_root/pets"
destination="$pets_dir/chickun"
staging_dir=""
backup_dir=""

cleanup() {
  local result=$?
  if [[ -n "$staging_dir" && -d "$staging_dir" ]]; then
    /bin/rm -rf -- "$staging_dir"
  fi
  if (( result != 0 )); then
    if [[ -n "$backup_dir" && ! -e "$destination" && ! -L "$destination" ]]; then
      /bin/mv -- "$backup_dir/chickun" "$destination" || true
    fi
    print -u2 -- "安装未完成，请保留上方错误信息。"
  fi
}
trap cleanup EXIT

if [[ ! -s "$source_dir/pet.json" || ! -s "$source_dir/spritesheet.webp" ]]; then
  print -u2 -- "缺少宠物文件。请先完整解压安装包，并让安装文件与 chickun 文件夹放在一起。"
  exit 1
fi

/bin/mkdir -p -- "$pets_dir"
if [[ -d "$destination" ]] &&
   /usr/bin/cmp -s "$source_dir/pet.json" "$destination/pet.json" &&
   /usr/bin/cmp -s "$source_dir/spritesheet.webp" "$destination/spritesheet.webp"; then
  print -- "鸡小坤 Chickun 已安装，当前版本完全相同。"
  print -- "安装位置：$destination"
  exit 0
fi

staging_dir=$(/usr/bin/mktemp -d "$pets_dir/.chickun-install.XXXXXX")
/bin/cp -- "$source_dir/pet.json" "$source_dir/spritesheet.webp" "$staging_dir/"
/usr/bin/cmp -s "$source_dir/pet.json" "$staging_dir/pet.json"
/usr/bin/cmp -s "$source_dir/spritesheet.webp" "$staging_dir/spritesheet.webp"

if [[ -e "$destination" || -L "$destination" ]]; then
  /bin/mkdir -p -- "$install_root/pet-backups"
  backup_dir=$(/usr/bin/mktemp -d "$install_root/pet-backups/chickun-$(/bin/date +%Y%m%d-%H%M%S).XXXXXX")
  /bin/mv -- "$destination" "$backup_dir/chickun"
fi

/bin/mv -- "$staging_dir" "$destination"
staging_dir=""
print -- "鸡小坤 Chickun 安装完成！"
print -- "练习时长两年半，喜欢唱、跳、Rap、篮球。"
print -- "安装位置：$destination"
if [[ -n "$backup_dir" ]]; then
  print -- "旧版本已备份：$backup_dir/chickun"
fi
print -- "可以返回 Codex 使用宠物了。"
